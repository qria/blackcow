# Blackcow

Play at: https://blackcow.qria.net

Game for 2019 UPnL Game Jam.

Theme: 딸기 and 흑우

Visual novel where the main protagonist is a serious flippin' sucker.

## Why did you make this?

Good Question.

I'm sorry.

## Installation

Download [Renpy] 7.3.2+ and set up renpy folder.

clone this inside that folder.

Run renpy and build.

[Renpy]: https://www.renpy.org/
